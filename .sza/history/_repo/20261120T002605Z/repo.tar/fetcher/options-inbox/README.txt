把从 FactSet Options Montage 下载的 optionsMontage_*.xlsx 直接丢进这个目录就行,
不用改名、不用整理。下一轮 `npm run fetch` 会自己认领属于各个标的的那几份。

导出的点法(实测走通):
  1. 打开 Options Montage,输入代码
  2. 行权价下拉 → Custom Strikes → % from At-the-Money 填 25 → OK
  3. 选一个月份页签
  4. 右上角工具图标 → Download

一次最多 500 个合约(= 行权价数 × 2)。超了会弹 "More than 500 contracts…",
而且是一个文件都不给,所以标的大的话按月份分几次下,脚本会自己拼。

这里面的 xlsx 是授权数据,已在 .gitignore 排除,不要提交。
